const MinimalLayout = (props) => {
    return props.children;
};

export default MinimalLayout;
